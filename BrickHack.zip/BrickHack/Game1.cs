﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace BrickHack
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        private gameState gS;
        private bool lose;
        private Texture2D chewieTex;
        //private Vector2 chewieVec;
        private Texture2D wookieTex;
        private Rectangle[] wookieRec;
        private KeyboardState kbState;
        private Rectangle chewbaccaRec;

        private Rectangle playBut;
        private Texture2D play;
        private Rectangle exitBut;
        private Texture2D exit;
        private Rectangle titleTxt;
        private Texture2D title;
        private Rectangle winRec;
        private Texture2D winPic;
        private Rectangle loseRec;
        private Texture2D losePic;

        private MouseState oldstate;
        private KeyboardState prevkbState;

        private Random randSize;
        private Random randX;

        private int size;

        public Game1()
            : base()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            gS = gameState.Menu;
            lose = false;
            //chewieVec = new Vector2(300, 300);
            chewbaccaRec = new Rectangle(400, 250, 20, 20);
            wookieRec = new Rectangle[10];

            titleTxt = new Rectangle(200, 0, 400, 200);
            playBut = new Rectangle(350, 150, 100, 100);
            exitBut = new Rectangle(350, 300, 100, 100);
            winRec = new Rectangle(-100, 50, 700, 500);
            loseRec = new Rectangle(0, 0, 800, 600);

            randSize = new Random();
            randX = new Random();

            for (int i = 0; i < wookieRec.Length; i++ )
            {
                size = randX.Next(5, 40);
                wookieRec[i] = new Rectangle(0, randX.Next(0, 400), size, size);
            }
            
            this.IsMouseVisible = true;

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            System.IO.Stream chewieStream =
                TitleContainer.OpenStream("Content/chewie.png");
            chewieTex = Texture2D.FromStream(
                this.GraphicsDevice,
                chewieStream);
            chewieStream.Close();

            System.IO.Stream wookieStream =
                TitleContainer.OpenStream("Content/wookie.png");
            wookieTex = Texture2D.FromStream(
                this.GraphicsDevice,
                wookieStream);
            wookieStream.Close();

            System.IO.Stream playStream =
                TitleContainer.OpenStream("Content/play.png");
            play = Texture2D.FromStream(
                this.GraphicsDevice,
                playStream);
            playStream.Close();
            exit = this.Content.Load<Texture2D>("exit.png");
            title = this.Content.Load<Texture2D>("title.png");
            winPic = this.Content.Load<Texture2D>("win.png");
            losePic = this.Content.Load<Texture2D>("lose.png");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            kbState = Keyboard.GetState();

            //Menu Screen
            if (gS == gameState.Menu)
            {
                MouseState mS = Mouse.GetState();

                if (mS.LeftButton == ButtonState.Pressed && oldstate.LeftButton == ButtonState.Released)
                {
                    //check if on play button
                    if (mS.X > 350 && mS.X < 450 && mS.Y > 150 && mS.Y < 250)
                    {
                        gS = gameState.Game;
                    }
                    //check if on exit button
                    else if (mS.X > 350 && mS.X < 450 && mS.Y > 300 && mS.Y < 400)
                    {
                        this.Exit();
                    }
                    else
                    {
                        gS = gameState.Menu;
                    }
                }
                oldstate = mS;
            }

            //Gameplay
            if (gS == gameState.Game)
            {
                //get movement
                if (kbState.IsKeyDown(Keys.Up))
                {
                    chewbaccaRec.Y -= 3;
                }
                
                if (kbState.IsKeyDown(Keys.Down))
                {
                    chewbaccaRec.Y += 3;
                }

                if (kbState.IsKeyDown(Keys.Left))
                {
                    chewbaccaRec.X -= 3;
                }

                if (kbState.IsKeyDown(Keys.Right))
                {
                    chewbaccaRec.X += 3;
                }

                if (chewbaccaRec.X < 0)
                {
                    chewbaccaRec.X = 790;
                }
                else if (chewbaccaRec.X > 791)
                {
                    chewbaccaRec.X = 1;
                }
                else if (chewbaccaRec.Y < 0)
                {
                    chewbaccaRec.Y = 484;
                }
                else if (chewbaccaRec.Y > 485)
                {
                    chewbaccaRec.Y = 0;
                }

                //check collisions
                for (int i = 0; i < wookieRec.Length; i++ )
                {
                    if (chewbaccaRec.Intersects(wookieRec[i]))
                    {
                        //if chewie is bigger
                        if (chewbaccaRec.Width * chewbaccaRec.Height > wookieRec[i].Height * wookieRec[i].Height)
                        {
                            if (chewbaccaRec.Height < 30)
                            {
                                size = randSize.Next(10, 50);
                            }
                            else if (chewbaccaRec.Height >= 30 && chewbaccaRec.Height < 60)
                            {
                                size = randSize.Next(20, 60);
                            }
                            else if (chewbaccaRec.Height >= 60 && chewbaccaRec.Height < 100)
                            {
                                size = randSize.Next(40, 80);
                            }
                            else if (chewbaccaRec.Height >= 100 && chewbaccaRec.Height < 150)
                            {
                                size = randSize.Next(60, 120);
                            }
                            else if (chewbaccaRec.Height >= 150)
                            {
                                size = randSize.Next(120, 170);
                            }
                            
                            wookieRec[i] = new Rectangle(0, randX.Next(0, 400), size, size);
                            chewbaccaRec.Height += 1;
                            chewbaccaRec.Width += 1;
                        }
                        //if he is smaller, you lose
                        else
                        {
                            lose = true;
                        }
                    }
                }

                //move the wookies
                for (int i = 0; i < wookieRec.Length; i++ )
                {
                    if (i < 5)
                    {
                        wookieRec[i].X += 2;
                    }
                    else
                    {
                        wookieRec[i].X -= 2;
                    }
                }

                //spawn new wookies if they hit the edge
                for (int i = 0; i < wookieRec.Length; i++ )
                {
                    if (wookieRec[i].X < 0)
                    {
                        if (chewbaccaRec.Height < 30)
                        {
                            size = randSize.Next(10, 50);
                        }
                        else if (chewbaccaRec.Height >= 30 && chewbaccaRec.Height < 60)
                        {
                            size = randSize.Next(20, 60);
                        }
                        else if (chewbaccaRec.Height >= 60 && chewbaccaRec.Height < 100)
                        {
                            size = randSize.Next(40, 80);
                        }
                        else if (chewbaccaRec.Height >= 100 && chewbaccaRec.Height < 150)
                        {
                            size = randSize.Next(60, 120);
                        }
                        else if (chewbaccaRec.Height >= 150)
                        {
                            size = randSize.Next(120, 170);
                        }
                        
                        wookieRec[i] = new Rectangle(780, randX.Next(0, 400), size, size);
                            
                    }
                    else if(wookieRec[i].X > 800)
                    {
                        if (chewbaccaRec.Height < 30)
                        {
                            size = randSize.Next(10, 50);
                        }
                        else if (chewbaccaRec.Height >= 30 && chewbaccaRec.Height < 60)
                        {
                            size = randSize.Next(20, 60);
                        }
                        else if (chewbaccaRec.Height >= 60 && chewbaccaRec.Height < 100)
                        {
                            size = randSize.Next(40, 80);
                        }
                        else if (chewbaccaRec.Height >= 100 && chewbaccaRec.Height < 150)
                        {
                            size = randSize.Next(60, 120);
                        }
                        else if (chewbaccaRec.Height >= 150)
                        {
                            size = randSize.Next(120, 170);
                        }
                        
                        wookieRec[i] = new Rectangle(0, randX.Next(0, 400), size, size);
                            
                    }
                }

                if (lose == true)
                {
                    gS = gameState.Over;
                }

                if (chewbaccaRec.Height >= 300)
                {
                    gS = gameState.Win;
                }
            }

            //Game Over
            if (gS == gameState.Over)
            {
                if (kbState.IsKeyDown(Keys.Space))
                {
                    this.Exit();
                }
            }

            //Win
            if (gS == gameState.Win)
            {
                if (kbState.IsKeyDown(Keys.Space))
                {
                    this.Exit();
                }
            }

            prevkbState = kbState;

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.White);

            //Menu Screen
            if (gS == gameState.Menu)
            {
                spriteBatch.Begin();

                spriteBatch.Draw(title, titleTxt, Color.White);
                spriteBatch.Draw(play, playBut, Color.White);
                spriteBatch.Draw(exit, exitBut, Color.White);

                spriteBatch.End();
            }

            //Gameplay
            if (gS == gameState.Game)
            {
                spriteBatch.Begin();

                spriteBatch.Draw(chewieTex, chewbaccaRec, Color.White);

                for (int i = 0; i < wookieRec.Length; i++ )
                {
                    spriteBatch.Draw(wookieTex, wookieRec[i], Color.White);
                }

                spriteBatch.End();
            }

            //Game Over
            if (gS == gameState.Over)
            {
                spriteBatch.Begin();

                spriteBatch.Draw(losePic, loseRec, Color.White);
                spriteBatch.Draw(wookieTex, new Rectangle(400, 30, 400, 400), Color.White);

                spriteBatch.End();
            }

            //Win
            if (gS == gameState.Win)
            {
                spriteBatch.Begin();

                spriteBatch.Draw(winPic, winRec, Color.White);
                spriteBatch.Draw(chewieTex, new Rectangle(400, 0, 400, 400), Color.White);               

                spriteBatch.End();
            }

            base.Draw(gameTime);
        }

        enum gameState
        {
            Menu,
            Game,
            Over,
            Win
        }
    }
}
